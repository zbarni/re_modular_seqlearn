#include <cmath>

int main(int argc, char const *argv[])
{
  std::isnan(0.0f/0.0f); 
  return 0;
}
