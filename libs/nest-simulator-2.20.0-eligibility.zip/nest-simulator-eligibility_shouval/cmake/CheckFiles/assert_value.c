#include <assert.h>
int
main()
{
  assert( 0 );
  return 0; // never reached
}
