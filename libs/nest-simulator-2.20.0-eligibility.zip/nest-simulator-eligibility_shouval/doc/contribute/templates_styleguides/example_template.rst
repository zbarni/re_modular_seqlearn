PyNEST example template
==========================


.. literalinclude:: pynest_example_template.py
