"""
Functions and defaults that are commonly used
"""

__all__ = ['data_handling', 'logger', 'operations', 'system']
